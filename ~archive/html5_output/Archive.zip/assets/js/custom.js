// Pre kgs Calculation (Slide 7)
$(function(){
    $('.pre_kgs_input').keyup(function(){
        var input_value = parseFloat($('.pre_kgs_input').val()) || 0;

        console.log(input_value);
      
        $('.pre_kgs_times3').html(Math.round(input_value * 3));

        $('.pre_kgs_times5').html(Math.round(input_value * 5));
      
        $('.pre_kgs_times7').html(Math.round(input_value * 7));

        $(".pre_kgs_reset").on("click", function(event) {
            $('.pre_kgs_input').val('');
            $('.pre_kgs_clear').empty();
        });
      
    });
});

// Pre lbs Calculation (Slide 7)
$(function(){
    $('.pre_lbs_input').keyup(function(){
        var input_value = parseFloat($('.pre_lbs_input').val()) || 0;

        console.log(input_value);
      
        $('.pre_lbs_times3').html(Math.round(input_value * 3));

        $('.pre_lbs_times5').html(Math.round(input_value * 5));
      
        $('.pre_lbs_times7').html(Math.round(input_value * 7));

        $(".pre_lbs_reset").on("click", function(event) {
            $('.pre_lbs_input').val('');
            $('.pre_lbs_clear').empty();
        });
      
    });
});

// During kgs Calculation (Slide 8)
$(function(){

    desktopKgPreExerciseInput = '.during_kgs_pre_mass';
    desktopKgPostExerciseInput = '.during_kgs_post_mass';
    desktopKgFluidEntakeInput = '.during_kgs_fluid_intake';
    desktopOutputKgSweatLoss = '.during_kgs_sweat_loss';

    during_kgs_exercise_time = '.during_kgs_exercise_time';
    
    kgOutputExerciseTime = '.during_kgs_exercise_time';
    kgOutputSweatRateTotal = '.during_kgs_sweat_rate';
    
    $( desktopKgFluidEntakeInput ).on('change', function() {
        let DesktopKgCalulationOne = $(desktopKgPreExerciseInput).val();
        let DesktopKgCalulationTwo = $(desktopKgPostExerciseInput).val();
        let DesktopKgCalulationThree = $(desktopKgFluidEntakeInput).val();
        let DesktopKgOutputOne = Number(DesktopKgCalulationOne) - Number(DesktopKgCalulationTwo) + Number(DesktopKgCalulationThree);
        
        $(desktopOutputKgSweatLoss).html(DesktopKgOutputOne);				
    });

    $( during_kgs_exercise_time ).on('change', function() {				
        let CalculateSweatLossInput = $(desktopOutputKgSweatLoss).html();
        let CalculateExerciseTimeInput = $(during_kgs_exercise_time).val();

        $(kgOutputExerciseTime).html(CalculateExerciseTimeInput);

        console.log('cal excercise Time:' + CalculateExerciseTimeInput);

        kgSweatRateTotal = Number(CalculateSweatLossInput) / Number(CalculateExerciseTimeInput);

        $(kgOutputSweatRateTotal).html((kgSweatRateTotal).toFixed(2));
    });

    $(".during_kgs_reset").on("click", function(event) {
        $('.during_kgs_input').val('');
        $('.during_kgs_clear').empty();
    });

});

// During lbs Calculation (Slide 8)
jQuery(function(){

    desktopLbPreExerciseInput = '.during_lbs_pre_mass';
    desktopLbPostExerciseInput = '.during_lbs_post_mass';
    desktopLbFluidEntakeInput = '.during_lbs_fluid_intake';
    desktopOutputLbSweatLoss = '.during_lbs_sweat_loss';

    exerciseTimeInput = '.during_lbs_exercise_time';

    lbOutputExerciseTime = '.during_lbs_exercise_time';
    lbOutputSweatRateTotal = '.during_lbs_sweat_rate';
    
    jQuery( desktopLbFluidEntakeInput ).on('change', function() {
        let DesktopLbCalulationOne = $(desktopLbPreExerciseInput).val();
        let DesktopLbCalulationTwo = $(desktopLbPostExerciseInput).val();
        let DesktopLbCalulationThree = $(desktopLbFluidEntakeInput).val();
        let DesktopLbOutputOne = Number(DesktopLbCalulationOne) - Number(DesktopLbCalulationTwo) + Number(DesktopLbCalulationThree);				
        
        $(desktopOutputLbSweatLoss).html(DesktopLbOutputOne);
    });

    jQuery( exerciseTimeInput ).on('change', function() {				
        let CalculateSweatLossInput = $(desktopOutputLbSweatLoss).html();
        let CalculateExerciseTimeInput = $(exerciseTimeInput).val();

        $(lbOutputExerciseTime).html(CalculateExerciseTimeInput);

        console.log('cal excercise Time:' + CalculateExerciseTimeInput);

        lbSweatRateTotal = Number(CalculateSweatLossInput) / Number(CalculateExerciseTimeInput);

        $(lbOutputSweatRateTotal).html((lbSweatRateTotal).toFixed(2));
    });

    $(".during_lbs_reset").on("click", function(event) {
        $('.during_lbs_input').val('');
        $('.during_lbs_clear').empty();
    });

});

// Post kgs Calculation (Slide 9)
jQuery(function(){
    desktopKgPreExerciseMassInput = '.post_kgs_pre_mass';
    desktopKgPostExerciseMassInput = '.post_kgs_post_mass';
    desktopOutputKgMassLoss = '.post_kgs_body_mass_loss';

    desktopOutputL120 = '.post_kgs_120_replacement';
    desktopOutputL150 = '.post_kgs_150_replacement';
    
    jQuery( desktopKgPostExerciseMassInput ).on('change', function() {
        let DesktopKgCalulationOne = $(desktopKgPreExerciseMassInput).val();
        let DesktopKgCalulationTwo = $(desktopKgPostExerciseMassInput).val();
        let DesktopKgMassOutputOne = Number(DesktopKgCalulationOne) - Number(DesktopKgCalulationTwo);
        
        $(desktopOutputKgMassLoss).html(DesktopKgMassOutputOne);
        
        let replacement120 = Number(DesktopKgMassOutputOne) * 1.2;
        let replacement150 = Number(DesktopKgMassOutputOne) * 1.5;

        $(desktopOutputL120).html(replacement120);
        $(desktopOutputL150).html(replacement150);
    });

    $(".post_kgs_reset").on("click", function(event) {
        $('.post_kgs_input').val('');
        $('.post_kgs_clear').empty();
    });

});

// Post lbs Calculation (Slide 9)
jQuery(function(){
    desktopLbPreExerciseMassInput = '.post_lbs_pre_mass';
    desktopLbPostExerciseMassInput = '.post_lbs_post_mass';
    desktopOutputLbMassLoss = '.post_lbs_body_mass_loss';

    desktopOutputOz120 = '.post_lbs_120_replacement';
    desktopOutputOz150 = '.post_lbs_150_replacement';
    
    jQuery( desktopLbPostExerciseMassInput ).on('change', function() {
        let DesktopLbCalulationOne = $(desktopLbPreExerciseMassInput).val();
        let DesktopLbCalulationTwo = $(desktopLbPostExerciseMassInput).val();
        let DesktopLbMassOutputOne = Number(DesktopLbCalulationOne) - Number(DesktopLbCalulationTwo);
        
        $(desktopOutputLbMassLoss).html(DesktopLbMassOutputOne);

        let replacement120 = Number(DesktopLbMassOutputOne) * 1.2;
        let replacement150 = Number(DesktopLbMassOutputOne) * 1.5;

        $(desktopOutputOz120).html(replacement120);
        $(desktopOutputOz150).html(replacement150);
    });

    $(".post_lbs_reset").on("click", function(event) {
        $('.post_lbs_input').val('');
        $('.post_lbs_clear').empty();
    });
});